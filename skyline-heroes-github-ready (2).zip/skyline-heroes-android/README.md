# Skyline Heroes Android

Android Studio project wrapping the supplied Skyline Heroes PWA in a WebView and integrating Google Mobile Ads rewarded ads.

AdMob App ID: ca-app-pub-6801970828861606~8563341058
Rewarded Ad Unit ID: ca-app-pub-6801970828861606/2076069734

Open this folder in Android Studio and build the APK. For development, use Google's test ad unit IDs until your implementation is verified.
