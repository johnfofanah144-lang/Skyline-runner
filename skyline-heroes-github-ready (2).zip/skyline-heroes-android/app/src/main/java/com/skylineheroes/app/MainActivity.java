package com.skylineheroes.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import android.webkit.JavascriptInterface;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;
    private static final String REWARDED_ID = "ca-app-pub-6801970828861606/2076069734";
    @Override public void onCreate(Bundle b) { super.onCreate(b);
        MobileAds.initialize(this, s -> loadRewarded());
        webView = new WebView(this); setContentView(webView);
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient()); webView.addJavascriptInterface(new AdBridge(), "AndroidAds");
        webView.loadUrl("file:///android_asset/index.html");
    }
    private void loadRewarded(){ AdRequest req=new AdRequest.Builder().build();
        RewardedAd.load(this, REWARDED_ID, req, new RewardedAdLoadCallback(){
            @Override public void onAdLoaded(RewardedAd ad){ rewardedAd=ad; }
            @Override public void onAdFailedToLoad(LoadAdError e){ rewardedAd=null; }
        }); }
    private void showRewarded(){
        if(rewardedAd!=null){ RewardedAd ad=rewardedAd; rewardedAd=null;
            ad.show(this, rewardItem -> webView.evaluateJavascript("window.dispatchEvent(new Event('androidReward'))", null));
            loadRewarded();
        } else { loadRewarded(); }
    }
    class AdBridge { @JavascriptInterface public void showRewardedAd(){ runOnUiThread(() -> showRewarded()); } }
}
