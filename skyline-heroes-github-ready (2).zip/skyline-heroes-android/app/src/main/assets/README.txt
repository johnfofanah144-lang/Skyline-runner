# Skyline Heroes Runner — installable web app starter

This package turns the supplied HTML game into a Progressive Web App (PWA) starter.
It can be hosted on an HTTPS website and installed from a compatible mobile browser.

## Test it on Android
1. Upload the files in this folder to a static HTTPS host (for example, a GitHub Pages site).
2. Open the hosted `index.html` in Chrome.
3. Use Chrome's menu and choose **Install app** or **Add to Home screen**.

Opening the HTML directly from your phone's file manager may run the game, but PWA installation/offline caching requires HTTPS or localhost.

## Important: earning money
The supplied game saves scores on the player's device by default. It does not currently pay players, show ad-network ads, or send earnings to you.
This package does not fake earnings or payouts. To earn revenue, you will need to:
- publish/host the game;
- register and be approved with a real ad/monetization provider that supports your country and app format;
- add the provider's approved ad code/SDK and comply with its policies;
- if you want Google Play distribution, package and test the app for Play Console requirements.

Do not promise players cash rewards until you have a funded, secure reward system and clear rules. Ad approval and revenue are not guaranteed.
